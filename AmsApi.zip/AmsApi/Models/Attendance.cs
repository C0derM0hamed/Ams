﻿namespace AmsApi.Models;

public class Attendance
{
    public Guid Id { get; set; }
    public Guid SubjectId { get; set; }
    public Guid AttendeeId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow; // إضافة CreatedAt
    public bool IsPresent { get; set; } // إضافة IsPresent

}
