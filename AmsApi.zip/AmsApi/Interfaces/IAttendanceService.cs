﻿namespace AmsApi.Interfaces
{
    public interface IAttendanceService
    {
        Task<List<AttendanceDto>> GetAttendanceBySubjectId(Guid subjectId);
        Task<bool> MarkAttendance(Guid subjectId, Guid attendeeId, MarkAttendanceDto dto);
        Task<AttendanceReportDto?> GetAttendanceReportAsync(Guid subjectId, DateTime date);
        byte[] GenerateAttendancePdf(string subjectName, DateTime date, List<string> present, List<string> absent);

        // إضافة دالة CreateMany لإنشاء حضور للعديد من المتدربين
        Task<bool> CreateMany(Guid subjectId, List<Guid> attendeeIds);

        // إضافة دالة DeleteById لحذف الحضور باستخدام الـ Id
        Task<bool> DeleteById(Guid attendanceId);
    }
}
