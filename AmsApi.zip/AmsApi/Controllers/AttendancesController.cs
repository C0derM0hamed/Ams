﻿namespace AmsApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendancesController : ControllerBase
    {
        private readonly IAttendanceService _attendanceService;

        public AttendancesController(IAttendanceService attendanceService)
        {
            _attendanceService = attendanceService;
        }

        // دالة GET للحصول على الحضور حسب SubjectId
        [HttpGet("subjects/{subjectId}")]
        public async Task<IActionResult> GetBySubject(Guid subjectId)
        {
            var result = await _attendanceService.GetAttendanceBySubjectId(subjectId);
            return Ok(result);
        }

        // دالة PUT لعلامة الحضور
        [HttpPut("subjects/{subjectId}/attendees/{attendeeId}")]
        public async Task<IActionResult> Mark(Guid subjectId, Guid attendeeId, MarkAttendanceDto dto)
        {
            var success = await _attendanceService.MarkAttendance(subjectId, attendeeId, dto);
            if (!success) return BadRequest("Attendance marking failed");

            return Ok(new { message = "Attendance updated successfully" });
        }

        // دالة GET للحصول على تقرير الحضور
        [HttpGet("report")]
        public async Task<IActionResult> GetAttendanceReport(Guid subjectId, DateTime date)
        {
            var report = await _attendanceService.GetAttendanceReportAsync(subjectId, date);
            if (report is null)
                return NotFound("Subject not found.");

            return Ok(report);
        }

        // دالة GET لتحميل تقرير الحضور بصيغة PDF
        [HttpGet("report/pdf")]
        public async Task<IActionResult> DownloadAttendanceReport(Guid subjectId, DateTime date)
        {
            var report = await _attendanceService.GetAttendanceReportAsync(subjectId, date);
            if (report == null)
                return NotFound("Subject not found or no attendees.");

            var pdfBytes = _attendanceService.GenerateAttendancePdf(
                report.Subject, report.Date, report.Present, report.Absent
            );

            return File(pdfBytes, "application/pdf", $"Attendance_{report.Subject}_{report.Date:yyyy-MM-dd}.pdf");
        }

        // دالة POST لإنشاء الحضور لعدة متدربين
        [HttpPost("subjects/{subjectId}/attendees")]
        public async Task<IActionResult> CreateMany(Guid subjectId, [FromBody] CreateAttendancesDto dto)
        {
            var success = await _attendanceService.CreateMany(subjectId, dto.AttendeeIds);
            if (!success) return BadRequest("Failed to mark attendance for attendees.");

            return Ok(new { message = "Attendances marked successfully" });
        }

        // دالة DELETE لحذف الحضور بناءً على الـ Id
        [HttpDelete("{attendanceId}")]
        public async Task<IActionResult> Delete(Guid attendanceId)
        {
            var success = await _attendanceService.DeleteById(attendanceId);
            if (!success) return NotFound("Attendance not found.");

            return NoContent();
        }
    }
}
