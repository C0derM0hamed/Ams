﻿public class CreateAttendancesDto
{
    public List<Guid> AttendeeIds { get; set; }  // قائمة بمعرفات المتدربين
}