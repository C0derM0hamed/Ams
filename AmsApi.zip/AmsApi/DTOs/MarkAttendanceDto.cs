﻿public class MarkAttendanceDto
{
    public bool IsPresent { get; set; }
}
