﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace AmsApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AttendeesController : ControllerBase
    {
        private readonly IAttendeeService _attendeeService;

        public AttendeesController(IAttendeeService attendeeService)
        {
            _attendeeService = attendeeService;
        }
      
        // Get all attendees
        [HttpGet]
        public async Task<IActionResult> GetAll([FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            if (claims == null || UserRole != "Admin")
                return Unauthorized(new { message = "Unauthorized access" });

            var attendees = await _attendeeService.GetAllAsync();
            return Ok(attendees);
        }

        // Create attendee
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateAttendeeDto dto, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;

            if (claims == null || UserRole != "Admin")
                return Unauthorized(new { message = "Unauthorized access" });

            var attendee = await _attendeeService.CreateAsync(dto);
            return CreatedAtAction(nameof(GetOne), new { id = attendee.Id }, attendee);
        }

        // Upload image for an attendee
        [HttpPost("{attendee_id}/image")]
        public async Task<IActionResult> UploadImage(Guid attendee_id, [FromForm] IFormFile file, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;

            if (claims == null || UserRole == "Attendee")
                return Unauthorized(new { message = "Unauthorized access" });

            if (file == null || file.Length == 0)
                return BadRequest(new { message = "No image file uploaded" });

            // Save Image Logic Here
            var imageBytes = await ImageHelper.SaveImageAsync(file);
            await _attendeeService.UploadImageAsync(attendee_id, imageBytes);

            return Ok(new { message = "Image uploaded successfully" });
        }


        // Get attendee by ID
        [HttpGet("{attendee_id}")]
        public async Task<IActionResult> GetOne(Guid attendee_id, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            var UserId = claims?.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;
            if (claims == null || (UserRole != "Admin" && UserId != attendee_id.ToString()))
                return Unauthorized(new { message = "Unauthorized access" });

            var attendee = await _attendeeService.GetByIdAsync(attendee_id);
            if (attendee == null)
                return NotFound();

            return Ok(attendee);
        }

        // Update attendee details
        [HttpPatch("{attendee_id}")]
        public async Task<IActionResult> Update(Guid attendee_id, [FromBody] UpdateAttendeeDto dto, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            if (claims == null || UserRole != "Admin")
                return Unauthorized(new { message = "Unauthorized access" });

            var updatedAttendee = await _attendeeService.UpdateAsync(attendee_id, dto);
            if (updatedAttendee == null)
                return NotFound();

            return Ok(updatedAttendee);
        }

        // Delete attendee
        [HttpDelete("{attendee_id}")]
        public async Task<IActionResult> Delete(Guid attendee_id, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            if (claims == null || UserRole != "Admin")
                return Unauthorized(new { message = "Unauthorized access" });

            var success = await _attendeeService.DeleteAsync(attendee_id);
            if (!success)
                return NotFound();

            return NoContent();
        }

        // Login with credentials
        [HttpPost("login")]
        public async Task<IActionResult> LoginWithCredentials([FromBody] LoginDto payload)
        {
            var attendee = await _attendeeService.GetByEmailAsync(payload.Username);
            if (attendee == null || attendee.Password != payload.Password)
                return Unauthorized(new { message = "Invalid credentials" });

            var token = JwtHelper.GenerateToken(attendee.Id, "Attendee");

            return Ok(new { token });
        }

        // Login with token
        [HttpGet("login")]
        public async Task<IActionResult> LoginWithToken([FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            var UserId = claims?.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

            if (claims == null || UserRole != "Attendee")
                return Unauthorized(new { message = "Unauthorized access" });

            var attendee = await _attendeeService.GetByIdAsync(Guid.Parse(UserId));
            if (attendee == null)
                return NotFound();

            return Ok(attendee);
        }
        // Get specific subject for a specific attendee
        [HttpGet("{attendee_id}/subjects/{subject_id}")]
        public async Task<IActionResult> GetOneSubjectForOne(Guid attendee_id, Guid subject_id, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            var UserId = claims?.FindFirst(JwtRegisteredClaimNames.Sub)?.Value;

            if (claims == null || (UserRole != "Admin" && UserId != attendee_id.ToString()))
                return Unauthorized(new { message = "Unauthorized access" });

            var subject = await _attendeeService.GetSubjectForAttendee(attendee_id, subject_id);
            if (subject == null)
                return NotFound();

            return Ok(subject);
        }

        // Add a subject to a specific attendee
        [HttpPut("{attendee_id}/subjects/{subject_id}")]
        public async Task<IActionResult> PutSubjectToAttendee(Guid attendee_id, Guid subject_id, [FromHeader] string jwtToken)
        {
            var claims = JwtHelper.ValidateToken(jwtToken);
            var UserRole = claims.FindFirst("role")?.Value;
            if (claims == null || UserRole != "Admin")
                return Unauthorized(new { message = "Unauthorized access" });

            var success = await _attendeeService.AddSubjectToAttendee(attendee_id, subject_id);
            if (!success)
                return NotFound();

            return Ok(new { message = "Subject added to attendee successfully" });
        }
    }
}
