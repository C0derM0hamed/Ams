﻿namespace AmsApi.DTOs
{
    public class UpdateAttendanceDto
    {
        public bool IsPresent { get; set; }
    }
}
