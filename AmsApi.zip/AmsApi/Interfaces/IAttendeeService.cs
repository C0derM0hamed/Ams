﻿namespace AmsApi.Interfaces
{
    public interface IAttendeeService
    {
        Task<Attendee> GetByIdAsync(Guid id);
        Task<Attendee> CreateAsync(CreateAttendeeDto dto);
        Task<Attendee> UpdateAsync(Guid id, UpdateAttendeeDto dto);
        Task<bool> DeleteAsync(Guid id);
        Task<List<Attendee>> GetAllAsync();
        Task UploadImageAsync(Guid attendeeId, byte[] imageBytes);
        Task<bool> AddSubjectToAttendee(Guid attendeeId, Guid subjectId);
        Task<Subject> GetSubjectForAttendee(Guid attendeeId, Guid subjectId);
        Task<Attendee> GetByEmailAsync(string email);
    }
}
