﻿namespace AmsApi.DTOs
{
    public class FaceRecognitionDto
    {
        public string? ModelName { get; set; }
        public float Threshold { get; set; }
    }
}
