﻿namespace AmsApi.Interfaces
{
    public interface ISubjectService
    {
       Task<IEnumerable<SubjectDto>> GetAllAsync();
        Task<SubjectDto?> GetByIdAsync(Guid id); // Change to Guid
        Task<SubjectDto> CreateAsync(CreateSubjectDto dto);
        Task<bool> UpdateAsync(Guid id, UpdateSubjectDto dto); // Change to Guid
        Task<bool> DeleteAsync(Guid id); // Change to Guid
        Task<bool> AddAttendeeToSubject(Guid subjectId, Guid attendeeId); // Change to Guid
        Task<bool> RemoveAttendeeFromSubject(Guid subjectId, Guid attendeeId); // Change to Guid
        Task<bool> AddInstructorToSubject(Guid subjectId, Guid instructorId); // Change to Guid
        Task<bool> RemoveInstructorFromSubject(Guid subjectId, Guid instructorId); // Change to Guid
    }
}
