﻿public class CreateSubjectDateDto
{
    public int SubjectId { get; set; }
    public DateTime Date { get; set; }
}