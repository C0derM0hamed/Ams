﻿namespace AmsApi.Interfaces;

public interface IInstructorService
{
    Task<Instructor> RegisterAsync(RegisterInstructorDto dto);
    Task<AuthResponse> LoginAsync(LoginInstructorDto dto);
    Task<Instructor?> UpdateAsync(Guid id, UpdateInstructorDto dto);  // تغيير int إلى Guid
    Task<Instructor?> GetByIdAsync(Guid id);  // تغيير int إلى Guid
    Task<bool> DeleteAsync(Guid id);  // تغيير int إلى Guid
}