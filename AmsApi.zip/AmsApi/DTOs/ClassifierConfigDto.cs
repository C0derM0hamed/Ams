﻿namespace AmsApi.DTOs
{
    public class ClassifierConfigDto
    {
        public string? Info { get; set; }
    }
}
