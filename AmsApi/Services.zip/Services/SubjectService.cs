﻿namespace AmsApi.Services
{
    public class SubjectService : ISubjectService
    {
        private readonly AmsDbContext _context;
        private readonly IMapper _mapper;

        public SubjectService(AmsDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SubjectDto>> GetAllAsync()
        {
            var subjects = await _context.Subjects.ToListAsync();
            return _mapper.Map<IEnumerable<SubjectDto>>(subjects);
        }

        public async Task<SubjectDto?> GetByIdAsync(Guid id)
        {
            var subject = await _context.Subjects.FindAsync(id);
            return subject is null ? null : _mapper.Map<SubjectDto>(subject);
        }

        public async Task<SubjectDto> CreateAsync(CreateSubjectDto dto)
        {
            var subject = _mapper.Map<Subject>(dto);
            _context.Subjects.Add(subject);
            await _context.SaveChangesAsync();

            return _mapper.Map<SubjectDto>(subject);
        }

        public async Task<bool> UpdateAsync(Guid id, UpdateSubjectDto dto)
        {
            var subject = await _context.Subjects.FindAsync(id);
            if (subject == null) return false;

            if (!string.IsNullOrWhiteSpace(dto.Name))
                subject.Name = dto.Name;

            if (!string.IsNullOrWhiteSpace(dto.Description))
                subject.Description = dto.Description;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(Guid id)
        {
            var subject = await _context.Subjects.FindAsync(id);
            if (subject == null) return false;

            _context.Subjects.Remove(subject);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> AddAttendeeToSubject(Guid subjectId, Guid attendeeId)
        {
            var subject = await _context.Subjects.FindAsync(subjectId);
            if (subject == null) return false;

            var existingAttendeeSubject = await _context.AttendeeSubjects
                .FirstOrDefaultAsync(ad => ad.SubjectId == subjectId && ad.AttendeeId == attendeeId);

            if (existingAttendeeSubject == null)
            {
                var attendeeSubject = new AttendeeSubject
                {
                    AttendeeId = attendeeId,
                    SubjectId = subjectId
                };

                _context.AttendeeSubjects.Add(attendeeSubject);
                await _context.SaveChangesAsync();
            }

            return true;
        }

        public async Task<bool> RemoveAttendeeFromSubject(Guid subjectId, Guid attendeeId)
        {
            var subject = await _context.Subjects.FindAsync(subjectId);
            if (subject == null) return false;

            var attendeeSubject = await _context.AttendeeSubjects
                .FirstOrDefaultAsync(ad => ad.SubjectId == subjectId && ad.AttendeeId == attendeeId);

            if (attendeeSubject != null)
            {
                _context.AttendeeSubjects.Remove(attendeeSubject);
                await _context.SaveChangesAsync();
            }

            return true;
        }

        public async Task<bool> AddInstructorToSubject(Guid subjectId, Guid instructorId)
        {
            var subject = await _context.Subjects.FindAsync(subjectId);
            if (subject == null) return false;

            if (subject.InstructorId != instructorId)
            {
                subject.InstructorId = instructorId;
                await _context.SaveChangesAsync();
            }

            return true;
        }

        public async Task<bool> RemoveInstructorFromSubject(Guid subjectId, Guid instructorId)
        {
            var subject = await _context.Subjects.FindAsync(subjectId);
            if (subject == null) return false;

            if (subject.InstructorId == instructorId)
            {
                subject.InstructorId = null;
                await _context.SaveChangesAsync();
            }

            return true;
        }
    }
}
