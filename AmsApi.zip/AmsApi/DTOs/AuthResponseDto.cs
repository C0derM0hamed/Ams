﻿public class AuthResponseDto
{
    public string Token { get; set; }
}