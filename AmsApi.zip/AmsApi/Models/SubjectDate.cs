﻿namespace AmsApi.Models;

public class SubjectDate
{
    public int Id { get; set; }
    public int SubjectId { get; set; }
    public DateTime Date { get; set; }

}

