﻿namespace AmsApi.DTOs
{
    public class CreateAttendeeDto
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public long Number { get; set; }
        public byte[]? Image { get; set; }
        public string? ImageFileName { get; set; }
        public double[]? Embedding { get; set; }  // Changed to double[] instead of List<double>
    }
}
