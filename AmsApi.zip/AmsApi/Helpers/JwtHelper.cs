﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace AmsApi.Helpers
{
    public static class JwtHelper
    {
        private static string SecretKey;
        private static string Issuer;
        private static string Audience;
        private static int ExpiryInMinutes;

        // Static constructor to initialize values from appsettings.json
        static JwtHelper()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            var config = builder.Build();

            // Read values from appsettings.json
            var jwtSettings = config.GetSection("JwtSettings");
            SecretKey = jwtSettings["SecretKey"]!;
            Issuer = jwtSettings["Issuer"]!;
            Audience = jwtSettings["Audience"]!;
            ExpiryInMinutes = int.Parse(jwtSettings["ExpiryInMinutes"]!);
        }

        public static string GenerateToken(Guid userId, string role)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()), // "sub" هو المستخدم
                new Claim("role", role) // "role" هو الدور
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: Issuer,
                audience: Audience,
                claims: claims,
                expires: DateTime.Now.AddMinutes(ExpiryInMinutes),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public static ClaimsPrincipal ValidateToken(string token)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
            var handler = new JwtSecurityTokenHandler();

            try
            {
                var jsonToken = handler.ReadToken(token) as JwtSecurityToken;
                var claims = jsonToken?.Claims;
                return new ClaimsPrincipal(new ClaimsIdentity(claims));
            }
            catch
            {
                return null; // في حالة كان الـ token غير صحيح
            }
        }
    }
}
